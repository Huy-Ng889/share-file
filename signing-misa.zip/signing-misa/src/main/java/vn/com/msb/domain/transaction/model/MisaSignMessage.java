package vn.com.msb.domain.transaction.model;

import lombok.Data;

@Data
public class MisaSignMessage {
    private String transactionId;
    private int authorizeMethod;
}
