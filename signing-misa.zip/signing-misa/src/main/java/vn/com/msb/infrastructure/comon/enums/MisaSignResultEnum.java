package vn.com.msb.infrastructure.comon.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MisaSignResultEnum {
    SUCCESS(0, "Thành công"),
    UNKNOWN_ERROR(1, "Lỗi chưa xác minh"),
    CLIENT_NOT_FOUND(2, "Không tìm thấy client (sai clientid, clientkey)"),
    INVALID_REQUEST_PARAM(3, "Tham số đầu vào không hợp lệ"),
    CERT_NOT_FOUND(4, "Không tìm thấy CTS"),
    CERT_EXPIRE(5, "CTS hết hiệu lực"),
    CERT_REVOKE(6, "CTS đã bị thu hồi"),
    CERT_LOCKED(7, "CTS bị khóa"),
    SIGN_REQUEST_EXPIRE(10, "Quá thời gian xác thực ký"),
    USER_CANCEL_SIGN_REQUEST(11, "Người dùng từ chối ký");
    private int code;
    private String desc;
}
