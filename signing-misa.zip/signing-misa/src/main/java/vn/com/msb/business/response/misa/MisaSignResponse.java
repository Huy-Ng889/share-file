package vn.com.msb.business.response.misa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MisaSignResponse {
    private Integer responseCode;
    private String responseMessage;
    private String transactionId;
    private String sicUrl;
}
