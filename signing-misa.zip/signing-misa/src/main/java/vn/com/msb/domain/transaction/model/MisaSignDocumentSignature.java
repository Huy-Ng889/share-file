package vn.com.msb.domain.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MisaSignDocumentSignature {
    private String documentId;
    private String signature;
}
