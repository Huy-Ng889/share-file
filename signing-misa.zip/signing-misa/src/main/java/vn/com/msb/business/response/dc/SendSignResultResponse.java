package vn.com.msb.business.response.dc;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendSignResultResponse {
    private boolean success;
    private String message;
}
