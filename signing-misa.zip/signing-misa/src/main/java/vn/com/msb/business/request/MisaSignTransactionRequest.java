package vn.com.msb.business.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MisaSignTransactionRequest extends BaseRequest{
    private MisaSignRequestData requestData;
}
