package vn.com.msb.infrastructure.config.logbook;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LogbookLog {
    private String name;
    private String logbook;
    private String uri;
}
