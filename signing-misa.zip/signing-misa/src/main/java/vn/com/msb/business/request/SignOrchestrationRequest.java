package vn.com.msb.business.request;

import lombok.Data;

@Data
public class SignOrchestrationRequest {
    private String transactionId;
    private String caProvider;
    private String event;
    private String payload;
}
