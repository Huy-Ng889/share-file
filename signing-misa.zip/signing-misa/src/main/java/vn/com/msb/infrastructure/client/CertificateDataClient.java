package vn.com.msb.infrastructure.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import vn.com.msb.domain.cert.InquiryCertDTO;
import vn.com.msb.domain.cert.model.Cert;
import vn.com.msb.domain.common.BaseResponse;
import vn.com.msb.infrastructure.comon.utils.Constant;

import java.util.List;

@FeignClient(
        name = "CertificateDataClient",
        url = "${certificate-data-service-name}")
public interface CertificateDataClient {
    @PostMapping("${certificate-data.inquiry-cert}")
    BaseResponse<List<Cert>> inquiryCert(@RequestHeader(name = "caProvider") String provider, @RequestBody InquiryCertDTO inquiryCertDTO);
}
