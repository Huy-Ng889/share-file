package vn.com.msb.business.response.misa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.transaction.model.MisaSignDocumentSignature;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetSignTransactionStatusResponse {
    private Integer responseCode;
    private String responseMessage;
    List<MisaSignDocumentSignature> signatures;
}
