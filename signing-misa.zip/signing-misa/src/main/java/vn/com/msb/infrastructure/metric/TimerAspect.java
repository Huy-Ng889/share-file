package vn.com.msb.infrastructure.metric;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.concurrent.TimeUnit;

@Aspect
@Component
@RequiredArgsConstructor
public class TimerAspect {
    private final MeterRegistry registry;

    @Around("@annotation(vn.com.msb.infrastructure.metric.DsTimer)")
    public Object timer(ProceedingJoinPoint joinPoint) throws Throwable {
        var signature = (MethodSignature) joinPoint.getSignature();
        var method = signature.getMethod();
        var annotation = method.getAnnotation(DsTimer.class);
        var uri = annotation.uri();
        Object result;
        var start = System.currentTimeMillis();
        try {
            result = joinPoint.proceed();
            var timer = TimerUtils.getBuilder()
                .tag(TimerUtils.STATUS, TimerUtils.STATUS_200)
                .tag(TimerUtils.URI, uri)
                .register(registry);
            timer.record(System.currentTimeMillis() - start, TimeUnit.MILLISECONDS);
            return result;
        } catch (ResponseStatusException e) {
            var timer = TimerUtils.getBuilder()
                .tag(TimerUtils.STATUS, String.valueOf(e.getStatus().value()))
                .tag(TimerUtils.URI, uri)
                .register(registry);
            timer.record(System.currentTimeMillis() - start, TimeUnit.MILLISECONDS);
            throw e;
        } catch (Throwable e) {
            var timer = TimerUtils.getBuilder()
                .tag(TimerUtils.STATUS, TimerUtils.STATUS_500)
                .tag(TimerUtils.URI, uri)
                .register(registry);
            timer.record(System.currentTimeMillis() - start, TimeUnit.MILLISECONDS);
            throw e;
        }
    }

}
