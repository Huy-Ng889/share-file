package vn.com.msb.infrastructure.config;

import feign.Logger;
import feign.RequestInterceptor;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.zalando.logbook.Logbook;
import org.zalando.logbook.openfeign.FeignLogbookLogger;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.comon.utils.Util;

@Configuration
public class FeignConfig {
    @Bean
    public Logger feignLogger(Logbook logbook) {
        return new FeignLogbookLogger(logbook);
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }

    @Bean
    public RequestInterceptor tracingFeignRequestInterceptor(Tracer tracer) {
        return template -> {
            var traceId = Util.getTraceId(tracer);
            template.header(Constant.X_TRACE_ID, traceId);
        };
    }

}
