package vn.com.msb.infrastructure.comon.constant;

public class AppConstant {
    public static final class ClientConfigName {
        public static final String SIGNED_FILE_FOLDER = "signedFileFolder";
        public static final String BUCKET = "bucket";
    }

    public static final class SignProcessEvent {
        public static final String HASH_SUCCESS = "HASH_SUCCESS";
        public static final String HASH_FAIL = "HASH_FAIL";
        public static final String MERGE_SUCCESS = "MERGE_SUCCESS";
        public static final String MERGE_FAIL = "MERGE_FAIL";
    }
}
