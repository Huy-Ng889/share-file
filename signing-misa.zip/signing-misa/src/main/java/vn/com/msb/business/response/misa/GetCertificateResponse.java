package vn.com.msb.business.response.misa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.cert.model.CertificateInfo;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GetCertificateResponse {
    private Integer responseCode;
    private String responseMessage;
    private CertificateInfo certificate;

}
