package vn.com.msb.business.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.stereotype.Service;
import vn.com.msb.business.response.ClientResponse;
import vn.com.msb.domain.client.ClientConfigDTO;
import vn.com.msb.infrastructure.client.ProviderClientManagementClient;
import vn.com.msb.infrastructure.comon.utils.Util;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientService {
    private final ProviderClientManagementClient providerClientManagementClient;
    private final Tracer tracer;

    public ClientConfigDTO getClientConfigByClientIdAndConfigName(String clientId, String configName) {
        List<ClientConfigDTO> clientConfigs = getClientConfigs(clientId);
        if (Objects.isNull(clientConfigs) || clientConfigs.isEmpty()) {
            return null;
        }
        clientConfigs = clientConfigs.stream().filter(e -> Objects.equals(e.getName(), configName)).collect(Collectors.toList());
        if (clientConfigs.isEmpty()) {
            return null;
        }
        return clientConfigs.get(0);
    }

    private List<ClientConfigDTO> getClientConfigs(String clientId) {
        log.info("get client config for client [{}]", clientId);
        try {
            ClientResponse clientResponse = providerClientManagementClient.getClientConfigs(clientId);
            if (Objects.nonNull(clientResponse.getData()) && !clientResponse.getData().isEmpty()) {
                return clientResponse.getData();
            }
        } catch (Exception ex) {
            log.error("get client config error for client [{}]", clientId, ex);
        }
        return Collections.emptyList();
    }
}
