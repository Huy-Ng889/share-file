package vn.com.msb.infrastructure.config.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Configuration
public class ThreadPoolExecutorBean {

    @Value(value = "${thread.pool.corePoolSize}")
    private int corePoolSize;

    @Value(value = "${thread.pool.maximumPoolSize}")
    private int maximumPoolSize;

    @Value(value = "${thread.pool.keepAliveTime}")
    private int keepAliveTime;

    @Value(value = "${thread.pool.queueCapacity}")
    private int queueCapacity;

    @Bean("defaultThreadPoolExecutor")
    public ThreadPoolExecutor threadPoolExecutor() {
        return new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime,
                TimeUnit.SECONDS, new ArrayBlockingQueue<>(queueCapacity));
    }
}
