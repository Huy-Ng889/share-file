package vn.com.msb.domain.client.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ClientConfig {
    private long id;

    private Long clientId;

    private String name;

    private String value;

    private LocalDateTime createdAt;

    private String createdBy;

    private LocalDateTime updatedAt;

    private String updatedBy;
}
