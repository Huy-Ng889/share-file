package vn.com.msb.infrastructure.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import vn.com.msb.business.response.ClientResponse;
import vn.com.msb.infrastructure.comon.utils.Constant;

@FeignClient(
        name = "provider-client-management-client",
        url = "${provider-client-management-service-name}"
)
public interface ProviderClientManagementClient {
    @GetMapping(value = "${d-signature.provider-client-management.get-client-config}")
    ClientResponse getClientConfigs(@PathVariable String id);
}
