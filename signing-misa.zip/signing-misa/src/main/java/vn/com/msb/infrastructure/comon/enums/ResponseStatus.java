package vn.com.msb.infrastructure.comon.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;

@Getter
@AllArgsConstructor
@ToString
public enum ResponseStatus {

    SUCCESS("0", OK),
    EXCEPTION_ERR("9999", HttpStatus.OK),

    //VNPT - Smart Ca
    REQUEST_PARTNER_EXCEPTION("110", HttpStatus.OK),
    ACCESS_DENIED("401", UNAUTHORIZED)

    ;

    private final String code;
    private final HttpStatus httpStatus;
}
