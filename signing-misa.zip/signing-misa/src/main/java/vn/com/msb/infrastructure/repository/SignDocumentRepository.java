package vn.com.msb.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.msb.domain.transaction.entity.SignDocumentEntity;

import java.util.List;

public interface SignDocumentRepository extends JpaRepository<SignDocumentEntity, Long> {
    List<SignDocumentEntity> findAllBySignDataId(Long signDataId);
}
