package vn.com.msb.infrastructure.comon.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@SuppressWarnings("java:S1118")
public class Constant {
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class MISA_API_HEADER {
        public static final String CLIENT_ID = "x-clientid";
        public static final String CLIENT_KEY = "x-clientkey";
    }
    public static final String COMMA = ",";
    public static final int NOT_HANDLED = 0;
    public static final int HANDLED = 1;
    public static final String SYSTEM = "E-SIGNATURE";
    public static final String PARTNER_VNPT = "VNPT";
    public static final String PARTNER_MISA = "MISA";
    public static final String MSB_API_KEY = "Msb-Api-Key";

    public static class ClientSettingStatus {
        public static final int ACTIVE = 1;
        public static final int INACTIVE = 0;
    }

    public static class ApiHeaderContentType {
        public static final String APP_JSON = "application/json";
    }

    public static class TimePattern {
        public static final String FORMAT_1 = "YYYYMMddHHmmSS";
    }
    public static class CA_PROVIDERS {
        public static final String VNPT = "VNPT";
        public static final String MISA = "MISA";
    }
    public static class ClientConfigsName {
        public static final String BUCKET = "bucket";
        public static final String CALLBACK_URL = "callback_url";
        public static final String KAFKA_TOPIC = "kafka_topic";
        public static final String PATH_SIGNED_FILE = "path_signed_file";
    }

    public static final String SUB = "-";
    public static final String X_TRACE_ID = "X-Trace-Id";
    public static final String TRACE_ID = "traceId";
    public static final String CORRELATION_ID = "correlationId";

    public static final String CLIENT_ID = "Client-Id";
    public static final String X_USER_TOKEN = "x-user-token";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String API_KEY = "Msb-Api-Key";
    public static final String CA_PROVIDER = "Ca-Provider";
    public static final String X_CLIENT_ID = "x-clientid";

}
