package vn.com.msb.business.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.itextpdf.text.DocumentException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import misa.esignrs.sdk.common.SignatureImagePosition;
import misa.esignrs.sdk.common.TextAlignment;
import misa.esignrs.sdk.pdf.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.msb.business.request.MisaSignRequestData;
import vn.com.msb.business.request.MisaSignTransactionRequest;
import vn.com.msb.domain.cert.InquiryCertDTO;
import vn.com.msb.domain.cert.model.Cert;
import vn.com.msb.domain.client.ClientConfigDTO;
import vn.com.msb.domain.common.GetFileMinioResponse;
import vn.com.msb.domain.common.MinIOService;
import vn.com.msb.domain.transaction.entity.HashDataEntity;
import vn.com.msb.domain.transaction.entity.SignDataEntity;
import vn.com.msb.domain.transaction.entity.SignDocumentEntity;
import vn.com.msb.domain.transaction.model.MisaSignDocInfo;
import vn.com.msb.domain.transaction.model.MisaSignDocument;
import vn.com.msb.infrastructure.comon.constant.AppConstant;
import vn.com.msb.infrastructure.comon.enums.MisaTransactionStatusEnum;
import vn.com.msb.infrastructure.comon.utils.CompletableFutureUtil;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.comon.utils.Util;
import vn.com.msb.infrastructure.metric.DsTimer;
import vn.com.msb.infrastructure.repository.HashDataRepository;
import vn.com.msb.infrastructure.repository.SignDataRepository;
import vn.com.msb.infrastructure.repository.SignDocumentRepository;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class HashDocumentService {
    private final SignDataRepository signDataRepository;
    private final SignDocumentRepository signDocumentRepository;
    private final HashDataRepository hashDataRepository;
    private final ObjectMapper objectMapper;
    private final CertService certService;
    private final MinIOService minioService;
    private final CompletableFutureUtil completableFutureUtil;

    @Value("${misa.sign-signature.location}")
    private String location;

    @Value("${misa.hash-file-concurrent}")
    private int misaHashFileConcurrent;

    @Autowired
    @Qualifier("defaultThreadPoolExecutor")
    Executor executor;

    @Value("${minio.d-signature.bucket}")
    private String dSignatureBucket;

    @Autowired
    private ProcessTransactionService processTransactionService;

    @Autowired
    private ClientService clientService;

    @DsTimer(uri = "/misa/hash/documents")
    public void handleSignRequest(SignDataEntity signDataEntity, int authorizeMethod) {
        log.info("handleSignRequest|signDataEntity: {}", signDataEntity);
        List<SignDocumentEntity> signDocumentEntities = signDocumentRepository.findAllBySignDataId(signDataEntity.getId());
        ClientConfigDTO clientBucketConfig = clientService.getClientConfigByClientIdAndConfigName(signDataEntity.getClientId(), AppConstant.ClientConfigName.BUCKET);
        String bucket = Objects.nonNull(clientBucketConfig) ? clientBucketConfig.getValue() : dSignatureBucket;
        List<HashDataEntity> hashDocumentEntities = hashDocument(signDataEntity, signDocumentEntities, bucket);
        signDataEntity.setStatus(MisaTransactionStatusEnum.HASH_SUCCESS.getCode());
        if (hashDocumentEntities.size() != signDocumentEntities.size()) {
            log.info("hash file error");
            signDataEntity.setStatus(MisaTransactionStatusEnum.HASH_FAIL.getCode());
        }
        log.info("hash success");
        signDataRepository.save(signDataEntity);
        signDocumentRepository.saveAll(signDocumentEntities);
        String event = AppConstant.SignProcessEvent.HASH_SUCCESS;
        if (Objects.equals(signDataEntity.getStatus(), MisaTransactionStatusEnum.HASH_FAIL.getCode())) {
            event = AppConstant.SignProcessEvent.HASH_FAIL;
        }
        MisaSignTransactionRequest request = buildMisaSignTransactionRequest(signDataEntity, hashDocumentEntities, signDocumentEntities, authorizeMethod);
        processTransactionService.publishEventToSignOrchestration(request.getTransactionId(), request.getRequestData(), event);
    }

    List<HashDataEntity> hashDocument(SignDataEntity signDataEntity, List<SignDocumentEntity> signDocumentEntities, String bucket) {
        if (Objects.isNull(signDocumentEntities) || signDocumentEntities.isEmpty()) {
            return Collections.emptyList();
        }
        List<MisaSignDocInfo> signDocInfos = parseSignDocInfo(signDocumentEntities);
        Map<Long, MisaSignDocInfo> signDocInfoMapBySignDocId = signDocInfos.stream().collect(Collectors.toMap(MisaSignDocInfo::getSignDocumentId, Function.identity(), (v1, v2) -> v2));
        InquiryCertDTO inquiryCertDTO = new InquiryCertDTO();
        inquiryCertDTO.setCertId(signDataEntity.getCertId());
        Cert certInfo = certService.getCertData(inquiryCertDTO, Constant.CA_PROVIDERS.MISA);
        log.info("[{}] hash file with cert [{}]", signDataEntity, certInfo);
        ArrayList<String> certInfos = new ArrayList<>(certInfo.getCertChainArr());
        List<HashDataEntity> hashDocumentEntities = new ArrayList<>();

        List<List<SignDocumentEntity>> signDocumentEntitiesPartition = Lists.partition(signDocumentEntities, misaHashFileConcurrent);
        for (List<SignDocumentEntity> documentEntities : signDocumentEntitiesPartition) {
            List<CompletableFuture<Void>> completableFutures = new ArrayList<>();
            for (SignDocumentEntity doc : documentEntities) {
                CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                    try {
                        hash(signDataEntity, bucket, doc, signDocInfoMapBySignDocId, certInfo, certInfos, hashDocumentEntities);
                        doc.setStatus(MisaTransactionStatusEnum.HASH_SUCCESS.getCode());
                    } catch (Exception e) {
                        doc.setStatus(MisaTransactionStatusEnum.HASH_FAIL.getCode());
                        log.error("[{}] Misa hash document fail with doc {} error-message: [{}]", signDataEntity.getTransactionId(), doc, e.getMessage(), e);
                    }
                }, executor);
                completableFutures.add(completableFuture);
            }
            completableFutureUtil.getAllCompleted(completableFutures);
        }
        return hashDataRepository.saveAll(hashDocumentEntities);
    }

    @DsTimer(uri = "/misa/hash/document")
    private void hash(SignDataEntity signDataEntity, String bucket, SignDocumentEntity doc, Map<Long, MisaSignDocInfo> signDocInfoMapBySignDocId, Cert certInfo, ArrayList<String> certInfos, List<HashDataEntity> hashDocumentEntities) throws GeneralSecurityException, DocumentException, IOException {
        MisaSignDocInfo signDocInfo = signDocInfoMapBySignDocId.getOrDefault(doc.getId(), new MisaSignDocInfo());
        GetFileMinioResponse getFileMinioResponse = minioService.getFileFromMinIoClientUse(signDataEntity.getClientId(), bucket, doc.getPathFile());
        PdfDocumentInfo documentInfo = new PdfDocumentInfo()
            .setDocumentName(doc.getDocName())
            .setDocument(getFileMinioResponse.getContent())
            .setContact(signDocInfo.getContact())
            .setDisplayText(certService.buildDisplayCert(certInfo))
            .setReason(signDocInfo.getReason())
            .setLocation(location)
            .setSignatureName(certInfo.getCertName())
            .setVisible(true)
            .setSignAllPages(signDocInfo.isSignAllPage())
            .setFont(signDocInfo.getFontName())
            .setRenderingMode(getRenderingModeByCode(signDocInfo.getVisibleType()))
            .setTextColor(getFontColorByCode(signDocInfo.getFontColor()))
            .setPositionSignature(getPositionSignatureByCode(signDocInfo.getSignaturePosition()))
            .setTextAlignment(getTextAlignByCode(signDocInfo.getTextAlign()));
        if (StringUtils.hasText(signDocInfo.getPage()) && Util.isNumeric(signDocInfo.getPage())) {
            documentInfo.setPage(Integer.parseInt(signDocInfo.getPage()));
        }
        SignatureImagePosition commonSignatureImagePosition = getSignatureImgPositionByCode(signDocInfo.getSignatureImagePosition());
        log.info("docId [{}], commonSignatureImagePosition: {}", doc.getDocId(), commonSignatureImagePosition);
        String signatureImage = signDocInfo.getSignatureImage();
        if (signatureImage != null) {
            byte[] signatureImgContent = Base64.getDecoder().decode(signatureImage);
            if (Objects.nonNull(signatureImgContent) && signatureImgContent.length > 0) {
                documentInfo.setSignatureImage(signatureImgContent);
                documentInfo.setSignatureImagePosition(commonSignatureImagePosition);
            }
        }
        List<PdfDocumentInfo> documentInfos = new ArrayList<>();
        documentInfos.add(documentInfo);
        PdfHashData hashData = new PdfHashData().setDocumentInfo(documentInfos).setCertificates(certInfos);
        PDFSigner pdfSigner = new PDFSigner(hashData, log);
        PdfHashResult pdfHashResult = pdfSigner.calculateHash();
        PdfHashedDocument hashedDoc = ((ArrayList<PdfHashedDocument>) pdfHashResult.getHashedDocuments()).get(0);
        HashDataEntity hashDocument = new HashDataEntity();
        hashDocument.setSignDocId(doc.getId());
        hashDocument.setHashData(Base64.getEncoder().encodeToString(hashedDoc.getDigest()));
        hashDocument.setHashObject(objectMapper.writeValueAsString(pdfHashResult));
        hashDocumentEntities.add(hashDocument);
    }

    List<MisaSignDocInfo> parseSignDocInfo(List<SignDocumentEntity> signDocumentEntities) {
        List<MisaSignDocInfo> signDocInfos = new ArrayList<>();
        for (SignDocumentEntity signDocumentEntity : signDocumentEntities) {
            try {
                MisaSignDocInfo signDocInfo = objectMapper.readValue(signDocumentEntity.getSignInfo(), MisaSignDocInfo.class);
                signDocInfo.setSignDocumentId(signDocumentEntity.getId());
                signDocInfos.add(signDocInfo);
            } catch (Exception e) {
                log.error("parseSignDocInfo error", e);
            }
        }
        return signDocInfos;
    }

    private MisaSignTransactionRequest buildMisaSignTransactionRequest(SignDataEntity signDataEntity, List<HashDataEntity> hashDataEntities,
                                                                       List<SignDocumentEntity> signDocumentEntities, int authorizeMethod) {
        Map<Long, String> hashData = hashDataEntities.stream().collect(Collectors.toMap(HashDataEntity::getSignDocId, HashDataEntity::getHashData, (v1, v2) -> v2));
        List<MisaSignDocument> misaSignDocuments = new ArrayList<>();
        for (SignDocumentEntity signDocumentEntity : signDocumentEntities) {
            MisaSignDocument misaSignDocument = new MisaSignDocument();
            misaSignDocument.setDocumentId(signDocumentEntity.getDocId());
            misaSignDocument.setDocumentName(signDocumentEntity.getDocName());
            misaSignDocument.setDocumentHash(hashData.get(signDocumentEntity.getId()));
            misaSignDocuments.add(misaSignDocument);
        }
        MisaSignTransactionRequest request = new MisaSignTransactionRequest();
        request.setTransactionId(signDataEntity.getTransactionId());
        MisaSignRequestData misaSignRequestData = new MisaSignRequestData();
        misaSignRequestData.setAuthorizeMethod(authorizeMethod);
        misaSignRequestData.setCertId(signDataEntity.getCertId());
        misaSignRequestData.setDocuments(misaSignDocuments);
        request.setRequestData(misaSignRequestData);
        return request;
    }

//    private void sendNotifyToClient(String transactionId) {
//        log.info("sendNotifyToClient|transaction id : {}", transactionId);
//        HttpHeaders headers = new HttpHeaders();
//        headers.set(Constant.MSB_API_KEY, msbApiKey);
//        headers.set("client_id", dcClientId);
//        headers.set("client_secret", dcClientSecret);
//        ClientNotifyRequest requestObj = new ClientNotifyRequest();
//        requestObj.setTransactionId(transactionId);
//        HttpEntity<Object> request = new HttpEntity<>(requestObj, headers);
//        log.info("sendNotifyToClient|request: {}", request);
//        ResponseEntity<ClientNotifyResponse> response = null;
//        try {
//            response = restTemplate.exchange(showOTPCallBackUrl, HttpMethod.POST, request, ClientNotifyResponse.class);
//            log.info("sendNotifyToClient - Response with data: {}", response);
//        } catch (Exception exception) {
//            log.error("sendNotifyToClient - Exchange - Exception !!!", exception);
//        }
//        if (response == null || !response.getStatusCode().is2xxSuccessful()) {
//            log.info("sendNotifyToClient - Response: {} --> http status is not 2xx !!!", response);
//            return;
//        }
//        if (response.getBody() == null) {
//            log.info("sendNotifyToClient - Response body is null !!!");
//        }
//    }

    private RenderingMode getRenderingModeByCode(String code) {
        switch (code) {
            case "DESCRIPTION":
                return RenderingMode.DESCRIPTION;
            case "GRAPHIC":
                return RenderingMode.GRAPHIC;
            default:
                return RenderingMode.GRAPHIC_AND_DESCRIPTION;
        }
    }

    private PDFSignatureColor getFontColorByCode(String code) {
        switch (code) {
            case "RED":
                return PDFSignatureColor.RED;
            case "WHITE":
                return PDFSignatureColor.WHITE;
            case "BLUE":
                return PDFSignatureColor.BLUE;
            default:
                return PDFSignatureColor.BLACK;
        }
    }

    private TextAlignment getTextAlignByCode(String code) {
        switch (code) {
            case "CENTER":
                return TextAlignment.CENTER;
            case "RIGHT":
                return TextAlignment.RIGHT;
            case "JUSTIFIED":
                return TextAlignment.JUSTIFIED;
            case "JUSTIFIED_ALL":
                return TextAlignment.JUSTIFIED_ALL;
            default:
                return TextAlignment.LEFT;
        }
    }

    private SignatureImagePosition getSignatureImgPositionByCode(String code) {
        switch (code) {
            case "TOP":
                return SignatureImagePosition.TOP;
            case "RIGHT":
                return SignatureImagePosition.RIGHT;
            case "BOTTOM":
                return SignatureImagePosition.BOTTOM;
            default:
                return SignatureImagePosition.LEFT;
        }
    }

    private PositionSignature getPositionSignatureByCode(String code) {
        switch (code) {
            case "TOP_LEFT":
                return PositionSignature.TOP_LEFT;
            case "TOP_RIGHT":
                return PositionSignature.TOP_RIGHT;
            case "BOTTOM_RIGHT":
                return PositionSignature.BOTTOM_RIGHT;
            default:
                return PositionSignature.BOTTOM_LEFT;
        }
    }
}
