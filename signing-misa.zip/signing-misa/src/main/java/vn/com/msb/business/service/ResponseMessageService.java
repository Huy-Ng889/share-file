package vn.com.msb.business.service;

import vn.com.msb.infrastructure.comon.enums.ResponseStatus;

public interface ResponseMessageService {

    String getMessage(ResponseStatus responseStatus);

}
