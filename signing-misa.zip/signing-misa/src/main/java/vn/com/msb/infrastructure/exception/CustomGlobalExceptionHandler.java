package vn.com.msb.infrastructure.exception;

import feign.RetryableException;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.zalando.logbook.Logbook;
import vn.com.msb.business.service.ResponseMessageService;
import vn.com.msb.domain.common.BaseResponse;
import vn.com.msb.infrastructure.comon.enums.ResponseStatus;
import vn.com.msb.infrastructure.comon.utils.JsonUtils;
import vn.com.msb.infrastructure.config.logbook.LogbookHttpRequest;
import vn.com.msb.infrastructure.config.logbook.LogbookHttpResponse;

import java.net.URI;
import java.util.Optional;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler {
    private final ResponseMessageService responseMessageService;
    private final Logbook logbook;

    @ExceptionHandler({Throwable.class})
    public final ResponseEntity<Object> handleThrowable(Exception ex) {
        log.error("handleThrowable exception", ex);
        return this.createResponse(ResponseStatus.EXCEPTION_ERR);
    }

    private ResponseEntity<Object> createResponse(ResponseStatus responseStatus) {
        BaseResponse<Object> responseData = new BaseResponse<>();
        responseData.setResponseCode(responseStatus.getCode());
        responseData.setResponseDesc(responseMessageService.getMessage(responseStatus));
        return new ResponseEntity<>(responseData, responseStatus.getHttpStatus());
    }

    private ResponseEntity<Object> createResponse(ResponseStatus responseStatus, Object data) {
        BaseResponse<Object> responseData = new BaseResponse<>();
        responseData.setResponseCode(responseStatus.getCode());
        responseData.setResponseDesc(responseMessageService.getMessage(responseStatus));
        responseData.setData(data);
        return new ResponseEntity<>(responseData, responseStatus.getHttpStatus());
    }

    @ExceptionHandler(RetryableException.class)
    public ResponseEntity<Object> handleRetryableException(RetryableException ex) {
        log.error("handleRetryableException", ex);
        try {
            var uri = URI.create(ex.request().url());
            var query = StringUtils.isNotBlank(uri.getQuery()) ? uri.getQuery() : "";
            var logbookRequest = LogbookHttpRequest.builder().schema(uri.getScheme()).host(uri.getHost()).port(Optional.of(uri.getPort())).path(uri.getPath()).query(query).build();
            var body = ex.responseBody().isPresent() ? JsonUtils.writeValueAsString(ex.responseBody().get().array()) : (StringUtils.isNotBlank(ex.contentUTF8()) ? ex.contentUTF8() : ex.getMessage());
            var logbookResponse = LogbookHttpResponse.builder()
                .status(ex.status() < 200 ? HttpStatus.UNPROCESSABLE_ENTITY.value() : ex.status())
                .body(JsonUtils.writeValueAsBytes(body))
                .build();
            logbook.process(logbookRequest).process(logbookResponse).write();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this.createResponse(ResponseStatus.EXCEPTION_ERR);
    }

}
