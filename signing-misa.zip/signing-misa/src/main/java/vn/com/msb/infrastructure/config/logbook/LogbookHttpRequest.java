package vn.com.msb.infrastructure.config.logbook;

import lombok.Builder;
import org.zalando.logbook.HttpHeaders;
import org.zalando.logbook.HttpRequest;
import org.zalando.logbook.Origin;

import java.io.IOException;
import java.util.Optional;

@Builder
public class LogbookHttpRequest implements HttpRequest {
    @Builder.Default
    private String remote = "";
    @Builder.Default
    private String method = "";
    @Builder.Default
    private String schema = "";
    @Builder.Default
    private String host = "";
    @Builder.Default
    private Optional<Integer> port = Optional.empty();
    @Builder.Default
    private String path = "";
    @Builder.Default
    private String query = "";
    @Builder.Default
    private Origin origin = Origin.REMOTE;
    @Builder.Default
    private HttpHeaders headers = HttpHeaders.empty();
    @Builder.Default
    private byte[] body = new byte[0];

    @Override
    public String getRemote() {
        return remote;
    }

    @Override
    public String getMethod() {
        return method;
    }

    @Override
    public String getScheme() {
        return schema;
    }

    @Override
    public String getHost() {
        return host;
    }

    @Override
    public Optional<Integer> getPort() {
        return port;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getQuery() {
        return query;
    }

    @Override
    public HttpRequest withBody() throws IOException {
        return this;
    }

    @Override
    public HttpRequest withoutBody() {
        return this;
    }

    @Override
    public Origin getOrigin() {
        return origin;
    }

    @Override
    public HttpHeaders getHeaders() {
        return headers;
    }

    @Override
    public byte[] getBody() throws IOException {
        return body;
    }
}
