package vn.com.msb.domain.transaction.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MisaSignDocInfo {
    private String contact;
    private String reason;
    private String visibleType;
    private String fontName;
    private String fontColor;
    private String textAlign;
    private String signatureImage;
    private String signatureImagePosition;
    private String signaturePosition;
    private boolean signAllPage;
    private String page;
    @JsonIgnore
    private Long signDocumentId;
}
