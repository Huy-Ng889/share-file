package vn.com.msb.domain.cert.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Entity
@Table(name = "cert_registers")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class CertRegisterEntity implements Serializable {
    @Id
    @Column(name = "id")
    private long id;
    @Column(name = "status")
    private Integer status;
    @Column(name = "cert_type")
    private Integer certType;
    @Column(name = "ca_provider")
    private String caProvider;
    @Column(name = "email", length = 128)
    private String email;
    @Column(name = "phone", length = 32)
    private String phoneNumber;
    @Column(name = "personal_name", length = 256)
    private String personalName;
    @Column(name = "title", length = 256)
    private String title;
    @Column(name = "personal_address", length = 500)
    private String personalAddress;
    @Column(name = "identity_type")
    private Integer identityType;
    @Column(name = "identity_number", length = 32)
    private String identityNumber;
    @Column(name = "identify_expire_date", length = 32)
    private String identityExpireDate;
    @Column(name = "identity_issue_date", length = 32)
    private String identityIssueDate;
    @Column(name = "tax_code", length = 50)
    private String taxCode;
    @Column(name = "company_name", length = 500)
    private String companyName;
    @Column(name = "company_address", length = 500)
    private String companyAddress;
    @Column(name = "transaction_id")
    private String transactionId;
    @Column(name = "partner_transaction_id")
    private String partnerTransactionId;
    @Column(name = "user_id")
    private String userId;
    @Column(name = "message")
    private String message;
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    @Column(name = "updated_by")
    private String updatedBy;
}
