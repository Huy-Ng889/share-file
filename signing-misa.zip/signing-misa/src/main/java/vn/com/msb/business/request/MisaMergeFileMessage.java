package vn.com.msb.business.request;

import lombok.Builder;
import lombok.Data;
import vn.com.msb.domain.transaction.model.MisaSignDocumentSignature;

import java.util.List;

@Data
@Builder
public class MisaMergeFileMessage {
    private String transactionId;
    private List<MisaSignDocumentSignature> signatures;
}
