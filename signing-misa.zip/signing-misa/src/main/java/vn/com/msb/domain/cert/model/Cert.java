package vn.com.msb.domain.cert.model;

import lombok.Data;
import vn.com.msb.infrastructure.comon.utils.Constant;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Data
public class Cert {
    private long id;
    private String userId;
    private String certId;
    private String caProvider;
    private Integer certStatus;
    private Integer certType;
    private String certName;
    private String certChain;
    private String serialNumber;
    private LocalDateTime effectiveTime;
    private LocalDateTime expirationTime;
    private long certRegisterId;

    public List<String> getCertChainArr() {
        return List.of(Objects.nonNull(certChain) ?
                certChain.split(Constant.COMMA) : new String[0]);
    }
}
