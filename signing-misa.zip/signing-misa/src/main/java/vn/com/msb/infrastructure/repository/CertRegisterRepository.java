package vn.com.msb.infrastructure.repository;


import vn.com.msb.domain.cert.entity.CertRegisterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CertRegisterRepository extends JpaRepository<CertRegisterEntity, Long> {

}
