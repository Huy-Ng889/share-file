package vn.com.msb.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import vn.com.msb.domain.transaction.entity.TransactionSignatureEntity;

import java.util.List;

@Repository
@Transactional
public interface TransactionSignatureRepository extends JpaRepository<TransactionSignatureEntity, Long> {
    List<TransactionSignatureEntity> findByTransactionIdAndCaProvider(String transactionId, String caProvider);
}
