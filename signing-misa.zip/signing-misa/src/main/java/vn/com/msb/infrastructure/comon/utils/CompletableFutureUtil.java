package vn.com.msb.infrastructure.comon.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CompletableFutureUtil {
    private static final long DEFAULT_TIMEOUT = 100L;

    private static final TimeUnit DEFAULT_TIME_UNIT = TimeUnit.SECONDS;

    public <T> List<T> getAllCompleted(List<CompletableFuture<T>> futureList) {
        CompletableFuture<Void> allFutureResult = CompletableFuture.allOf(futureList.toArray(new CompletableFuture[futureList.size()]));
        try {
            allFutureResult.get();
        } catch (Exception e) {
            log.error("CompletableFutureUtil error", e);
        }
        return futureList.stream()
                .filter(future -> future.isDone() && !future.isCompletedExceptionally())
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
    }
}
