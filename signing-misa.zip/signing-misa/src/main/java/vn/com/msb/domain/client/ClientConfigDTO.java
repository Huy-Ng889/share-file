package vn.com.msb.domain.client;

import lombok.Data;

@Data
public class ClientConfigDTO {
    private Long id;
    private Long clientId;
    private String name;
    private String value;
}
