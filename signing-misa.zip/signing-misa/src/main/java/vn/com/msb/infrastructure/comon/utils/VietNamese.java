package vn.com.msb.infrastructure.comon.utils;

import java.text.Normalizer;

/**
 * @author kienvt2
 */
public class VietNamese {

    static char mang[][] = new char[][] { { 'À', 'Á', 'Ả', 'Ã', 'Ạ', 'Â', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ', 'Ắ', 'Ằ', 'Ă', 'Ặ' }, // 0
            { 'Đ' }, // 1
            { 'È', 'É', 'Ẻ', 'Ẽ', 'Ẹ', 'Ê', 'Ề', 'Ế', 'Ể', 'Ễ', 'Ệ' }, // 2
            { 'Ì', 'Í', 'Ỉ', 'Ĩ', 'Ị' }, // 3
            { 'Ò', 'Ó', 'Ỏ', 'Õ', 'Ọ', 'Ô', 'Ồ', 'Ố', 'Ổ', 'Ỗ', 'Ộ', 'Ơ', 'Ờ', 'Ớ', 'Ở', 'Ỡ', 'Ợ' },
            { 'Ù', 'Ú', 'Ủ', 'Ũ', 'Ụ', 'Ư', 'Ừ', 'Ứ', 'Ử', 'Ữ', 'Ự' }, { 'Ỳ', 'Ý', 'Ỷ', 'Ỹ', 'Ỵ' },
            { 'à', 'á', 'ả', 'ã', 'ạ', 'â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ', 'ắ', 'ằ', 'ă', 'ặ' }, { 'đ' },
            { 'è', 'é', 'ẻ', 'ẽ', 'ẹ', 'ê', 'ề', 'ế', 'ể', 'ễ', 'ệ' }, { 'ì', 'í', 'ỉ', 'ĩ', 'ị' },
            { 'ò', 'ó', 'ỏ', 'õ', 'ọ', 'ô', 'ồ', 'ố', 'ổ', 'ỗ', 'ộ', 'ơ', 'ờ', 'ớ', 'ở', 'ỡ', 'ợ' },
            { 'ù', 'ú', 'ủ', 'ũ', 'ụ', 'ư', 'ừ', 'ứ', 'ử', 'ữ', 'ự' }, { 'ỳ', 'ý', 'ỷ', 'ỹ', 'ỵ' }, { '\r', '\n' }

    };
    static char[] mangR = new char[] { 'A', 'D', 'E', 'I', 'O', 'U', 'Y', 'a', 'd', 'e', 'i', 'o', 'u', 'y', ' ' };

    public static char search(char x) {
        for (int u = 0; u < mang.length; u++)
            for (int v = 0; v < mang[u].length; v++)
                if (x == mang[u][v])
                    return mangR[u];
        return x;
    }

    public static String clearVN(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        s = Normalizer.normalize(s, Normalizer.Form.NFC);
        String temp = "";
        for (int i = 0; i < s.length(); i++)
            temp += search(s.charAt(i));
        return temp.replaceAll("[^a-zA-Z0-9&@\\-/!$%\'&()_+/?., ]+", "");
        // ~!@#$%^&*()_+:{}'
    }

    public static String clearVNAdvance(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        s = Normalizer.normalize(s, Normalizer.Form.NFC);
        String temp = "";
        for (int i = 0; i < s.length(); i++)
            temp += search(s.charAt(i));
        return temp.replaceAll("[^a-zA-Z0-9&@\\-/!$%\'&()_+/?.,;: ]+", "");
        // ~!@#$%^&*()_+:{}'
    }

    public static String clearVNCharOnly(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        s = Normalizer.normalize(s, Normalizer.Form.NFC);
        String temp = "";
        for (int i = 0; i < s.length(); i++)
            temp += search(s.charAt(i));
        return temp;
        // ~!@#$%^&*()_+:{}'
    }

    public static void main(String[] args) {
//        String dd = "{\"idFrontImage\":null,\"selfieImage\":null,\"cardInfoResult\":{\"requestId\":\"b39ce6b8-fd21-45b7-9ccc-e8e5470e6814\",\"rawQR\":\"\",\"infos\":[{\"value\":\"29/10/2019\",\"field\":\"issue_date\",\"confidenceVerdict\":\"SURE\",\"confidenceScore\":1},{\"value\":\"CỤC TRUỞNG CỤC CẢNH SÁT QUẢN LÝ HÀNH CHÍNH VÀ TRẬT TỰ XÃ HỘI\",\"field\":\"issue_place\",\"confidenceVerdict\":\"\",\"confidenceScore\":1},{\"value\":\"vn.cmnd_new\",\"field\":\"card_type\"},{\"value\":\"vn.cmnd_new.back\",\"field\":\"card_label\"}]},\"idTamperingResult\":{\"score\":0,\"requestId\":\"cc60ad2d-a899-443c-8e39-cb04b3d104f4\",\"isGood\":true},\"idSanityResult\":{\"score\":1,\"requestId\":\"1606d060-4d9c-4212-9f40-3f86f0666224\",\"isGood\":true},\"idBackImageUrl\":\"/data/user/0/vn.com.msb.smartBanking/app_temp/id_back.png\",\"idBackImageId\":\"4b979437-e593-457e-85d8-57ec426a0cea\",\"croppedIdFrontImageId\":\"dedae526-62aa-460e-b046-e11a6a511c27\",\"cardType\":{\"requireBackside\":true,\"orientation\":\"HORIZONTAL\",\"cardName\":\"CMND c? / CMND m?i / CCCD / H? chi?u\",\"cardId\":\"vn.national_id\"},\"actionMode\":\"READ_CARD_INFO_ONE_SIDE\"}";
//        System.out.println(dd.length());
//        System.out.println(clearVNAdvance(dd));
//        System.out.println(clearVN(dd).length());
        System.out.println(clearVN("Không phải dạng vừa đấu !!"));
    }

}
