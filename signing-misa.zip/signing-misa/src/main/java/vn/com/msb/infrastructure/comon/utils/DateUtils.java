package vn.com.msb.infrastructure.comon.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateUtils {
    public static String getTimeGMT7() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        // set time zone HCM
        sdf.setTimeZone(TimeZone.getTimeZone("VST"));
        return sdf.format(calendar.getTime());
    }

    public static Date getDateTimeGMT7(String time) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            sdf.setTimeZone(TimeZone.getTimeZone("VST"));
            return sdf.parse(time);
        }
        catch (Exception ex){
            ex.printStackTrace();
            return null;
        }
    }

    public static boolean equalsDate(Date date1, Date date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);
        return calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR)
                && calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH)
                && calendar1.get(Calendar.DAY_OF_MONTH) == calendar2.get(Calendar.DAY_OF_MONTH);
    }

    private String getSequenceByDate(){
        Date toDay = new Date();
        return String.valueOf(toDay.getTime());
    }

    public static String getTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());

        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmm");
        // set time zone HCM
        sdf.setTimeZone(TimeZone.getTimeZone("VST"));
        return sdf.format(calendar.getTime());
    }

    public static String getDate(){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());

        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
        // set time zone HCM
        sdf.setTimeZone(TimeZone.getTimeZone("VST"));
        return sdf.format(calendar.getTime());
    }

    public static String formatFileNameByDate(String date, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Date dateFormat = sdf.parse(date);
            SimpleDateFormat sdf1 = new SimpleDateFormat(format);
            return sdf1.format(dateFormat);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return date;
        }
    }

    public static String formatFileNameByDate(String date, String format, String formatResult) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            Date dateFormat = sdf.parse(date);
            SimpleDateFormat sdf1 = new SimpleDateFormat(formatResult);
            return sdf1.format(dateFormat);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return date;
        }
    }

    public static String formatTranDateByDate(String date, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date dateFormat = sdf.parse(date);
            SimpleDateFormat sdf1 = new SimpleDateFormat(format);
            return sdf1.format(dateFormat);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return date;
        }
    }

    public static String getDate(String format){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());

        SimpleDateFormat sdf = new SimpleDateFormat(format);
        // set time zone HCM
        sdf.setTimeZone(TimeZone.getTimeZone("VST"));
        return sdf.format(calendar.getTime());
    }

    public static String getTimeStampMillisGMT7() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.setTimeZone(TimeZone.getTimeZone("VST"));
        return String.valueOf(calendar.getTimeInMillis());
    }
}
