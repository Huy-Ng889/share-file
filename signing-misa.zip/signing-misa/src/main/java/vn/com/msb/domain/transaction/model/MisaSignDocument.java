package vn.com.msb.domain.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MisaSignDocument {
    private String documentId;
    private String documentName;
    private String documentHash;
}
