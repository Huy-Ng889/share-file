package vn.com.msb.domain.transaction.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.common.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "sign_documents")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SignDocumentEntity extends BaseEntity {
    @Column(name = "sign_data_id")
    private Long signDataId;

    @Column(name = "doc_id")
    private String docId;

    @Column(name = "doc_name")
    private String docName;

    @Column(name = "path_file")
    private String pathFile;

    @Column(name = "signed_path_file")
    private String signedPathFile;

    @Column(name = "sign_info")
    private String signInfo;

    @Column(name = "status")
    private int status;
}
