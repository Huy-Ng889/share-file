package vn.com.msb.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import vn.com.msb.domain.client.entity.ClientConfigEntity;

import java.util.List;

@Transactional
@Repository
public interface ClientConfigRepository extends JpaRepository<ClientConfigEntity, Long> {
    ClientConfigEntity findByClientIdAndName(Long clientId, String name);

    @Query(value = "select * " +
            " from client_configs " +
            " where client_id = (select id from clients where clients.client_id = :clientId)", nativeQuery = true)
    List<ClientConfigEntity> findAllByClientId(String clientId);

//    @Query(value = "select * " +
//            " from client_configs cc" +
//            " where cc.client_id = (select c.id from clients c where c.client_id = :clientId) and cc.name = :configName", nativeQuery = true)
//    ClientConfigEntity findFirstByClientIdAndConfigName(String clientId, String configName);
}
