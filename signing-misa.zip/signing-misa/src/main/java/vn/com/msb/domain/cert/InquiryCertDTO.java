package vn.com.msb.domain.cert;

import lombok.Data;

@Data
public class InquiryCertDTO {
    private String userId;
    private String certId;
    private String identityNumber;
    private Integer certType;
    private String taxCode;
    private int certStatus;
}
