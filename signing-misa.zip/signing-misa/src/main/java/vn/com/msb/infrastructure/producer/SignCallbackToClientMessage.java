package vn.com.msb.infrastructure.producer;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SignCallbackToClientMessage {
    private String transactionId;
}
