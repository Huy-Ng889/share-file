package vn.com.msb.infrastructure.comon.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public enum OutboxEvTypeEnum {
    SEND_SIGN_RESULT_TO_PARTNER("SEND_SIGN_RESULT_TO_PARTNER", "Gửi kết quả ký cho hệ thống vệ tinh"),
    SEND_MISA_SIGN_RESULT_TO_CLIENT("SEND_MISA_SIGN_RESULT_TO_CLIENT", "Gửi kết quả ký từ MISA cho hệ thống vệ tinh");

    private String key;
    private String value;
}
