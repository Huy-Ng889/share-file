package vn.com.msb.infrastructure.comon.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.fasterxml.jackson.databind.util.StdDateFormat;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import lombok.extern.slf4j.Slf4j;
import vn.com.msb.infrastructure.comon.enums.ResponseStatus;
import vn.com.msb.infrastructure.exception.BusinessException;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

@Slf4j
public class JsonUtils {

    public static final ObjectMapper mapper = createObjectMapper();

    public static String writeValueAsString(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("writeValueAsString | {}", e.getMessage(), e);
            var reason = "error writeValueAsString";
            throw new BusinessException(ResponseStatus.EXCEPTION_ERR);
        }
    }

    private static ObjectMapper createObjectMapper() {
        return new ObjectMapper()
                .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
                .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .setPropertyNamingStrategy(PropertyNamingStrategy.LOWER_CAMEL_CASE)
                .setDateFormat(new StdDateFormat())
                .registerModules(
                        new ParameterNamesModule(), new Jdk8Module(), new JavaTimeModule(),
                        new SimpleModule()
                                .addDeserializer(String.class, new StringTrimDeserializer())
                                .addSerializer(Instant.class, new InstantSerializer())
                                .addSerializer(Timestamp.class, new TimestampDeserializer())
                );
    }

    private static class InstantSerializer extends StdSerializer<Instant> {
        private InstantSerializer() {
            super(Instant.class);
        }
        @Override
        public void serialize(Instant value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeString(value.truncatedTo(ChronoUnit.SECONDS).toString());
        }
    }

    private static class StringTrimDeserializer extends JsonDeserializer<String> {
        @Override
        public String deserialize(JsonParser p, DeserializationContext ctx) throws IOException {
            return p.getValueAsString().trim();
        }
    }

    private static class TimestampDeserializer extends StdSerializer<Timestamp> {
        private TimestampDeserializer() {
            super(Timestamp.class);
        }
        @Override
        public void serialize(Timestamp value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeString(value.toInstant().toString());
        }
    }

    public static String objectToJson(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            return null;
        }
    }


    public static <T> T readValueFromJson(String message, Class<T> returnType) {

        try {
            return mapper.readValue(message, returnType);
        } catch (Exception ex) {
            log.error(message + " DsVNPTConsumer - getSignMessage - got Ex: {}", ex.getMessage());
            return null;
        }
    }

    public static byte[] writeValueAsBytes(Object obj) {
        if (Objects.isNull(obj)) {
            return new byte[0];
        }
        try {
            return mapper.writeValueAsBytes(obj);
        } catch (JsonProcessingException e) {
            log.error("writeValueAsBytes | {}", e.getMessage(), e);
            var reason = "error writeValueAsBytes";
            throw new BusinessException(ResponseStatus.EXCEPTION_ERR);
        }
    }

}
