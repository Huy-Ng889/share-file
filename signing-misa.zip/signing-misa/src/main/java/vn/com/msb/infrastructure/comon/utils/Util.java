package vn.com.msb.infrastructure.comon.utils;

import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;
import org.springframework.cloud.sleuth.Tracer;

import java.lang.reflect.Field;
import java.util.*;

@Slf4j
@SuppressWarnings("java:S3011")
public class Util {
    public static void trimStringFields(Object obj, String... name) {
        Set<String> fieldsToIgnore = new HashSet<>(Arrays.asList(name));

        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (!fieldsToIgnore.contains(field.getName()) && field.getType() == String.class) {
                try {
                    field.setAccessible(true);
                    String value = (String) field.get(obj);
                    if (value != null) {
                        field.set(obj, value.trim());
                    }
                } catch (IllegalAccessException e) {
                    log.info("trimStringFields - Exception !!!", e);
                }
            }
        }
    }

    public static String limitContentError(String input) {
        if (null != input && input.length() > 999) {
            return input.substring(0, 998);
        }
        return input;
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static String getTraceId(Tracer tracer) {
        var xCorrelationId = Optional.ofNullable(MDC.get(Constant.CORRELATION_ID)).filter(StringUtils::isNotBlank).orElse(null);
        if (StringUtils.isNotBlank(xCorrelationId)) {
            return xCorrelationId;
        }
        var xTraceId = Optional.ofNullable(MDC.get(Constant.TRACE_ID)).filter(StringUtils::isNotBlank).orElse(null);
        if (StringUtils.isNotBlank(xTraceId)) {
            return xTraceId;
        }
        return (tracer.currentSpan() != null && tracer.currentSpan().context() != null && StringUtils.isNotBlank(tracer.currentSpan().context().traceId())) ? tracer.currentSpan().context().traceId() : UUID.randomUUID().toString().replace(Constant.SUB, StringUtils.EMPTY);
    }

}
