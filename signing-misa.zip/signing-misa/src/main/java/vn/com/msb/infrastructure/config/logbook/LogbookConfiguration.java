package vn.com.msb.infrastructure.config.logbook;

import lombok.RequiredArgsConstructor;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;
import org.zalando.logbook.*;
import org.zalando.logbook.json.JsonHttpLogFormatter;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.comon.utils.JsonUtils;
import vn.com.msb.infrastructure.comon.utils.Util;
import vn.com.msb.infrastructure.producer.KafkaProducer;

@Configuration
@RequiredArgsConstructor
public class LogbookConfiguration {
    private final Tracer tracer;
    private final KafkaProducer kafkaProducer;

    static class CorrelationIdFromTracer implements CorrelationId {
        private final Tracer tracer;
        public CorrelationIdFromTracer(Tracer tracer) {
            this.tracer = tracer;
        }
        @Override
        public String generate(HttpRequest request) {
            var traceIdHeader = request.getHeaders().get(Constant.X_TRACE_ID);
            if (CollectionUtils.isEmpty(traceIdHeader)) {
                return Util.getTraceId(tracer);
            }
            return traceIdHeader.get(0);
        }
    }

    private HeaderFilter headerFilter() {
        return headers -> HttpHeaders.of(Constant.X_TRACE_ID, getValue(headers, Constant.X_TRACE_ID))
            .update(Constant.CLIENT_ID, getValue(headers, Constant.CLIENT_ID))
            .update(Constant.X_USER_TOKEN, getValue(headers, Constant.X_USER_TOKEN))
            .update(Constant.CONTENT_TYPE, getValue(headers, Constant.CONTENT_TYPE))
            .update(Constant.API_KEY, getValue(headers, Constant.API_KEY))
            .update(Constant.CA_PROVIDER, getValue(headers, Constant.CA_PROVIDER))
            .update(Constant.X_CLIENT_ID, getValue(headers, Constant.X_CLIENT_ID))
        ;
    }

    private String getValue(HttpHeaders headers, String key) {
        if (headers.containsKey(key)) {
            return headers.get(key).get(0);
        }
        return null;
    }

    @Bean
    public Sink logbookSink() {
        return new LogbookSink(new JsonHttpLogFormatter(JsonUtils.mapper), kafkaProducer);
    }

    @Bean
    public Logbook logbook(Sink logbookSink) {
        return Logbook.builder().correlationId(new CorrelationIdFromTracer(tracer)).headerFilter(headerFilter()).sink(logbookSink).build();
    }

}
