package vn.com.msb.infrastructure.config.minio;

import io.minio.MinioClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class MinioConfig {

    @Value("${minio.bank-wide.endpoint}")
    private String minioBankWideEndpoint;

    @Value("${minio.d-signature.access-key}")
    private String minioBankWideAccessKey;

    @Value("${minio.d-signature.secret-key}")
    private String minioBankWideSecretKey;

    @Value("${minio.prod.access-key}")
    private String minioProdAccessKey;

    @Value("${minio.prod.secret-key}")
    private String minioProdSecretKey;

    @Value("${minio.prod.endpoint}")
    private String minioProdEndpoint;

    @Bean
    @Primary
    public MinioClient minioClient() {
        return MinioClient.builder()
                .endpoint(minioBankWideEndpoint)
                .credentials(minioBankWideAccessKey, minioBankWideSecretKey)
                .build();
    }

    @Bean
    public MinioClient minioProdClient() {
        return MinioClient.builder()
                .endpoint(minioProdEndpoint)
                .credentials(minioProdAccessKey, minioProdSecretKey)
                .build();
    }
}
