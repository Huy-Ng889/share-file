package vn.com.msb.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.msb.domain.transaction.entity.SignDataEntity;

public interface SignDataRepository extends JpaRepository<SignDataEntity, Long> {
    SignDataEntity findByTransactionIdAndCaProvider(String transactionId, String caProvider);
}
