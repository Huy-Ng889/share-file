package vn.com.msb.infrastructure.comon.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MisaTransactionStatusEnum {
    NOT_HANDLED(0, "Chưa xử lý"),
    HASH_FAIL(-1, "Hash file thất bại"),
    HASH_SUCCESS(1, "Hash file thành công"),
    MERGE_FAIL(-2, "Merge file thất bại"),
    MERGE_SUCCESS(2, "Merge file thành công");
//    RECEIVE_SUCCESS(0, "D-Signature đã tiếp nhận hồ sơ thành công"),
//    REQUEST_SIGN_TO_PROVIDER_SUCCESS(4, "Gửi yêu cầu ký thành công"),
//    SIGN_SUCCESS(5, "Ký thành công"),
//    SIGN_FAILED(-5, "Ký thất bại"),
//    SIGN_SCA_SUCCESS_HSM_FAILED(7, "Ký cá nhân thành công pháp nhân thất bại"),
//    SIGN_REQUEST_EXPIRED(-8, "Yêu cầu ký hết hạn"),
//    SIGN_REQUEST_REJECTED(-9, "Yêu cầu ký bị từ chối"),
//    PARTNER_SIGN_FAIL(-11, "Partner sign failed"),
//    CONFIRM_OTP_SUCCESS(9, "Confirm OTP success");
    private final int code;
    private final String message;
}
