package vn.com.msb.infrastructure.config.logbook;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.comon.utils.Util;

import java.io.IOException;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class TraceIdFilter extends OncePerRequestFilter {
    private final Tracer tracer;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        var traceId = getOrGenerateTraceId(request);
        try {
            MDC.put(Constant.TRACE_ID, traceId);
            MDC.put(Constant.CORRELATION_ID, traceId);
            response.setHeader(Constant.X_TRACE_ID, traceId);
            filterChain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }

    private String getOrGenerateTraceId(HttpServletRequest request) {
        var traceId = Optional.ofNullable(request.getHeader(Constant.X_TRACE_ID)).filter(StringUtils::isNotBlank).orElse(null);
        if (StringUtils.isNotBlank(traceId)) {
            return traceId;
        }
        return Util.getTraceId(tracer);
    }

}
