package vn.com.msb.infrastructure.comon.utils;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

public class GsonFactory {

    private static Gson gson;

    public static Gson createGson() {
        if (gson == null) {
            gson = new GsonBuilder()
                    .disableHtmlEscaping()
                    .setExclusionStrategies(new ExclusionStrategy() {
                        @Override
                        public boolean shouldSkipField(FieldAttributes f) {
                            return f.getAnnotation(Expose.class) != null;
                        }

                        @Override
                        public boolean shouldSkipClass(Class<?> clazz) {
                            return false;
                        }
                    })
                    .create();
        }
        return gson;
    }

    public static String toJSONString(Object object) {
        return createGson().toJson(object);
    }

    public static class CamelCaseFieldNamingStrategy implements FieldNamingStrategy {

        @Override
        public String translateName(java.lang.reflect.Field field) {
            String name = field.getName();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < name.length(); i++) {
                char ch = name.charAt(i);
                if ('A' <= ch && ch <= 'Z') {
                    sb.append(("_" + ch).toLowerCase());
                } else {
                    sb.append(ch);
                }

            }
            return sb.toString();
        }

    }
}
