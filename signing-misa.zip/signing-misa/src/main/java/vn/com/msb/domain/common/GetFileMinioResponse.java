package vn.com.msb.domain.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class GetFileMinioResponse implements Serializable {
    private static final long serialVersionUID = -1958504092081707874L;

    String fileName;

    byte[] content;
}
