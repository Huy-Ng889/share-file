package vn.com.msb.domain.common;

import io.minio.*;
import io.minio.errors.ErrorResponseException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

@Service
@Slf4j
public class MinIOService {
    @Value("${minio.prod.client-id}")
    private List<String> clientUseMinioProd;
    @Autowired
    private MinioClient minioClient;

    @Autowired
    @Qualifier("minioProdClient")
    private MinioClient minioProdClient;


    public GetFileMinioResponse getFile(String bucketName, String path) {

        try (GetObjectResponse object = minioClient.getObject(GetObjectArgs.builder()
                .bucket(bucketName)
                .object(path)
                .build())) {
            String fileName = object.object();

            if (null != fileName) {
                int lastIndex = fileName.lastIndexOf("/");
                fileName = fileName.substring(lastIndex + 1);
            }

            byte[] content = object.readAllBytes();
            return GetFileMinioResponse.builder()
                    .fileName(fileName)
                    .content(content)
                    .build();
        } catch (Throwable e) {
            log.error("Minio - Get file on minio failed !!!", e);
            return null;
        }
    }

    public boolean isExistedFile(String bucketName, String path) {
        try {
            minioClient.statObject(StatObjectArgs.builder()
                    .bucket(bucketName)
                    .object(path)
                    .build());
            return true;
        } catch (ErrorResponseException er) {
            log.info("Minio - Check file existed - Not found path:" + path + " in bucket:" + bucketName, er);
            return false;
        } catch (Exception e) {
            log.info("Minio - Check file existed -- path:" + path + " in bucket:" + bucketName + " - Exception !!!", e);
            return false;
        }
    }

    public GetFileMinioResponse getFileFromMinioProd(String bucket, String path) {
        try (GetObjectResponse object = minioProdClient.getObject(GetObjectArgs.builder()
                .bucket(bucket)
                .object(path)
                .build())) {
            String fileName = object.object();

            if (null != fileName) {
                int lastIndex = fileName.lastIndexOf("/");
                fileName = fileName.substring(lastIndex + 1);
            }

            byte[] content = object.readAllBytes();
            return GetFileMinioResponse.builder()
                    .fileName(fileName)
                    .content(content)
                    .build();
        } catch (Throwable e) {
            log.error("Minio - Get file on minio failed !!!", e);
            return null;
        }
    }

    public boolean uploadFile(String bucketName, String path, String fileName, String fileType, byte[] content) {
        try {

            File tempFile = File
                    .createTempFile(fileName.replaceAll("\\.", ""),
                            ".".concat(fileType), new File("/opt/app"));
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(content);
            }

            minioClient.uploadObject(
                    UploadObjectArgs.builder()
                            .bucket(bucketName)
                            .object(path.concat(fileName))
                            .filename(tempFile.getAbsolutePath())
                            .build());

            // Clean up the temporary file
            boolean isDeleted = tempFile.delete();
            log.info("Minio - Upload file -- path:" + path + " in bucket:" + bucketName + " - Clean up the temporary file: {}", isDeleted);

            return true;
        } catch (Exception e) {
            log.error("Minio - Upload file -- path:" + path + " in bucket:" + bucketName + " - Exception !!!", e);
            return false;
        }
    }

    public GetFileMinioResponse getFileFromMinIoClientUse(String clientId, String bucket, String pathFile) {
        if (clientUseMinioProd.contains(clientId)) {
            log.info("get file from MinIO Prod");
            return getFileFromMinioProd(bucket, pathFile);
        }
        log.info("get file from MinIO BankWide");
        return getFile(bucket, pathFile);
    }
}
