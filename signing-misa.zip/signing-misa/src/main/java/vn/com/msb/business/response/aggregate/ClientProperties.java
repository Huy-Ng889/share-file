package vn.com.msb.business.response.aggregate;

import lombok.Data;

@Data
public class ClientProperties {
    private String clientId;
    private String bucket;
    private String callBackUrl;
    private String kafkaTopic;
    private String pathSignedFile;
}
