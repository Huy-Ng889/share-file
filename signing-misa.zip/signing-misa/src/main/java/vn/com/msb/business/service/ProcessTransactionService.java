package vn.com.msb.business.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.stereotype.Service;
import vn.com.msb.business.request.ProcessTransactionRequest;
import vn.com.msb.business.request.SignOrchestrationRequest;
import vn.com.msb.domain.transaction.entity.SignDataEntity;
import vn.com.msb.infrastructure.client.SignProcessClient;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.comon.utils.Util;

import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProcessTransactionService {
    private final SignProcessClient signProcessClient;
    private final ObjectMapper objectMapper;
    private final Tracer tracer;

    public void updateTransactionProcess(SignDataEntity signDataEntity, int status) {
        log.info("start change process state");
        ProcessTransactionRequest request = new ProcessTransactionRequest();
        request.setTransactionId(signDataEntity.getTransactionId());
        request.setCaProvider(signDataEntity.getCaProvider());
        request.setStatus(status);
        try {
            signProcessClient.changeProcessTransactionState(request);
        } catch (Exception e) {
            log.error("updateTransactionProcess error {}", request, e);
        }
    }

    public void publishEventToSignOrchestration(String transactionId, Object payload, String event) {
        try {
            log.info("start publish sign orchestration");
            SignOrchestrationRequest request = new SignOrchestrationRequest();
            request.setTransactionId(transactionId);
            request.setCaProvider(Constant.CA_PROVIDERS.MISA);
            request.setEvent(event);
            if (Objects.nonNull(payload)) {
                request.setPayload(objectMapper.writeValueAsString(payload));
            }
            signProcessClient.publishEventToSignOrchestration(request);
        } catch (Exception e) {
            log.error("publishEventToSignOrchestration error: tranId = {}, payload = {}, event = {}", transactionId, payload, event);
        }
    }
}
