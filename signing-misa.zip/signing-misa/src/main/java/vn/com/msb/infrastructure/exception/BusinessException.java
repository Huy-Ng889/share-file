package vn.com.msb.infrastructure.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import vn.com.msb.infrastructure.comon.enums.ResponseStatus;

import java.io.Serializable;

@RequiredArgsConstructor
@AllArgsConstructor
@Getter
@SuppressWarnings("java:S1948")
public class BusinessException extends RuntimeException implements Serializable {

    private static final long serialVersionUID = -3680288195056057167L;

    private final ResponseStatus responseStatus;

    private Object data;
}
