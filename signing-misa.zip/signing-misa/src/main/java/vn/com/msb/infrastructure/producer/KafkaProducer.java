package vn.com.msb.infrastructure.producer;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.KafkaException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import vn.com.msb.infrastructure.comon.utils.JsonUtils;

@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaProducer {
    private final KafkaTemplate<String, String> kafkaTemplate;

    public void send(String topic, String key, Object data) {
        try {
            kafkaTemplate.send(topic, key, JsonUtils.writeValueAsString(data))
                        .completable()
                        .whenComplete((result, ex) -> {
                            if (ex != null) {
                                log.error("KafkaProducer|send|ERROR|topic|{}|key|{}", topic, key, ex);
                            }
                            log.info("KafkaProducer|send|SUCCESS|topic|{}|key|{}|result|{}", topic, key, result.toString());
                        });
        } catch (KafkaException | org.springframework.kafka.KafkaException e) {
            log.error("send | KafkaException | {} | {} | {}", topic, key, e.getMessage(), e);
        } catch (Exception e) {
            log.error("send | Exception | {} | {} | {}", topic, key, e.getMessage(), e);
        }
    }

    public void send(String topic, Object data) {
        try {
            kafkaTemplate.send(topic, JsonUtils.writeValueAsString(data))
                        .completable()
                        .whenComplete((result, ex) -> {
                            if (ex != null) {
                                log.error("KafkaProducer|send|ERROR|topic|{}", topic, ex);
                            }
                            log.info("KafkaProducer|send|SUCCESS|topic|{}|result|{}", topic, result.toString());
                        });
        } catch (KafkaException | org.springframework.kafka.KafkaException e) {
            log.error("send | KafkaException | {} | {}", topic, e.getMessage(), e);
        } catch (Exception e) {
            log.error("send | Exception | {} | {} }", topic, e.getMessage(), e);
        }
    }

    public void sendString(String topic, String key, String data) {
        try {
            kafkaTemplate.send(topic, key, data)
                        .completable()
                        .whenComplete((result, ex) -> {
                            if (ex != null) {
                                log.error("KafkaProducer|sendString|ERROR|topic|{}|key|{}", topic, key, ex);
                            }
                            log.info("KafkaProducer|sendString|SUCCESS|topic|{}|key|{}|result|{}", topic, key, result.toString());
                        });
        } catch (KafkaException | org.springframework.kafka.KafkaException e) {
            log.error("sendString | KafkaException | {} | {} | {}", topic, key, e.getMessage(), e);
        } catch (Exception e) {
            log.error("sendString | Exception | {} | {} | {}", topic, key, e.getMessage(), e);
        }
    }
}
