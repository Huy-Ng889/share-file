package vn.com.msb.infrastructure.comon.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RecordSignTypeEnum {

    HASH_FILE("hash", "Hash file when send sign request"),
    MERGE_FILE("merge", "Merge file when receive result signing from provider");

    private final String key;
    private final String description;
}
