package vn.com.msb.business.service;

import vn.com.msb.domain.cert.InquiryCertDTO;
import vn.com.msb.domain.cert.model.Cert;
import vn.com.msb.domain.cert.model.CertificateInfo;

public interface CertService {
    CertificateInfo getCertificateInfo(String certId);

    String buildDisplayCert(Cert certInfo);
    Cert getCertData(InquiryCertDTO inquiryCertDTO, String provider);
}
