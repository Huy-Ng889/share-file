package vn.com.msb.domain.cert.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CertificateInfo {
    private String userId;
    private String certId;
    private Integer certStatus;
    private Integer certType;
    private String certName;
    private List<String> certChain;
    private String serialNumber;
    private String effectiveDate;
    private String expirationDate;
    @JsonIgnore
    private Long certRegisterId;
}
