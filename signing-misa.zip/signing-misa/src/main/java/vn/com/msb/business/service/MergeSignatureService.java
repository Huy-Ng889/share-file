package vn.com.msb.business.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import misa.esignrs.sdk.pdf.PDFSigner;
import misa.esignrs.sdk.pdf.PdfAttachSignatureData;
import misa.esignrs.sdk.pdf.PdfHashResult;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import vn.com.msb.domain.client.ClientConfigDTO;
import vn.com.msb.domain.common.MinIOService;
import vn.com.msb.domain.transaction.entity.HashDataEntity;
import vn.com.msb.domain.transaction.entity.SignDataEntity;
import vn.com.msb.domain.transaction.entity.SignDocumentEntity;
import vn.com.msb.domain.transaction.entity.TransactionSignatureEntity;
import vn.com.msb.infrastructure.comon.constant.AppConstant;
import vn.com.msb.infrastructure.comon.enums.MisaTransactionStatusEnum;
import vn.com.msb.infrastructure.comon.utils.CompletableFutureUtil;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.metric.DsTimer;
import vn.com.msb.infrastructure.repository.HashDataRepository;
import vn.com.msb.infrastructure.repository.SignDataRepository;
import vn.com.msb.infrastructure.repository.SignDocumentRepository;
import vn.com.msb.infrastructure.repository.TransactionSignatureRepository;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MergeSignatureService {
    private final SignDataRepository signDataRepository;
    private final ObjectMapper objectMapper;
    private final CompletableFutureUtil completableFutureUtil;
    private final MinIOService minioService;
    private final HashDataRepository hashDataRepository;
    private final TransactionSignatureRepository transactionSignatureRepository;
    private final SignDocumentRepository signDocumentRepository;
    private final ProcessTransactionService processTransactionService;

    @Value("${misa.merge-file-concurrent}")
    private int mergeFileConcurrentSize;

    @Value("${minio.d-signature.bucket}")
    private String dSignBucket;

    @Autowired
    @Qualifier("defaultThreadPoolExecutor")
    private Executor executor;

    @Autowired
    private ClientService clientService;

    @DsTimer(uri = "/misa/merge/documents")
    public void handleMergeSignature(String transactionId) {
        try {
            log.info("SigningMisaConsumer start merge file {}", transactionId);
            SignDataEntity signDataEntity = signDataRepository.findByTransactionIdAndCaProvider(transactionId, Constant.CA_PROVIDERS.MISA);
            if (Objects.isNull(signDataEntity)) {
                throw new Exception("Not found record for transactionId[" + transactionId + "]");
            }
            if (!Objects.equals(signDataEntity.getStatus(), MisaTransactionStatusEnum.HASH_SUCCESS.getCode())) {
                throw new Exception("signData[" + signDataEntity + "] is handled");
            }
            List<TransactionSignatureEntity> transactionSignatureEntities =
                    transactionSignatureRepository.findByTransactionIdAndCaProvider(signDataEntity.getTransactionId(), Constant.CA_PROVIDERS.MISA);
            List<SignDocumentEntity> misaSignDocumentEntities = signDocumentRepository.findAllBySignDataId(signDataEntity.getId());
            mergeSignature(signDataEntity, transactionSignatureEntities, misaSignDocumentEntities);
            String event = AppConstant.SignProcessEvent.MERGE_SUCCESS;
            if (Objects.equals(signDataEntity.getStatus(), MisaTransactionStatusEnum.MERGE_FAIL.getCode())) {
                event = AppConstant.SignProcessEvent.MERGE_FAIL;
            }
            processTransactionService.publishEventToSignOrchestration(transactionId, null, event);
        } catch (Exception e) {
            log.error("SigningMisaConsumer merge error: {}", transactionId, e);
        }
    }

    private void mergeSignature(SignDataEntity signData, List<TransactionSignatureEntity> signatures, List<SignDocumentEntity> signDocumentEntities) {
        if (Objects.isNull(signatures) || signatures.isEmpty()) {
            log.info("get transaction, signatures is empty");
            return;
        }
        log.info("[{}} start merge signature", signData.getTransactionId());
        ClientConfigDTO clientSignedPathFileConfig = clientService.getClientConfigByClientIdAndConfigName(signData.getClientId(), AppConstant.ClientConfigName.SIGNED_FILE_FOLDER);
        if (Objects.isNull(clientSignedPathFileConfig)) {
            log.info("not found client config signed folder");
            return;
        }
        List<Long> signDocumentIdsNeedMergeSignature = signDocumentEntities.stream().map(SignDocumentEntity::getId).collect(Collectors.toList());
        Map<String, String> signatureByDocId = signatures.stream().collect(Collectors.toMap(TransactionSignatureEntity::getDocId, TransactionSignatureEntity::getSignature, (v1, v2) -> v2));
        List<HashDataEntity> hashDocumentEntities = hashDataRepository.findBySignDocIdIn(signDocumentIdsNeedMergeSignature);
        Map<Long, String> hashInfoBySignDocId = hashDocumentEntities.stream().collect(Collectors.toMap(HashDataEntity::getSignDocId, HashDataEntity::getHashObject, (v1, v2) -> v2));

        List<List<SignDocumentEntity>> signDocumentEntitiesPartition = Lists.partition(signDocumentEntities, mergeFileConcurrentSize);
        AtomicBoolean isMergeSignatureSuccess = new AtomicBoolean(true);
        for (List<SignDocumentEntity> documentEntities : signDocumentEntitiesPartition) {
            List<CompletableFuture<Void>> completableFutures = new ArrayList<>();

            for (SignDocumentEntity signDoc : documentEntities) {
                CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                    try {
                        String signedPathFile = merge(signData, signDoc, hashInfoBySignDocId, signatureByDocId, clientSignedPathFileConfig);
                        signDoc.setSignedPathFile(signedPathFile);
                        signDoc.setStatus(MisaTransactionStatusEnum.MERGE_SUCCESS.getCode());
                        log.info("[{}] merge signature success {}", signData.getTransactionId(), signDoc);
                    } catch (Throwable e) {
                        isMergeSignatureSuccess.set(false);
                        signDoc.setStatus(MisaTransactionStatusEnum.MERGE_FAIL.getCode());
                        log.error("[{}] merge signature failed for docId [{}], error message=[{}]", signData.getTransactionId(), signDoc.getDocId(), e.getMessage(), e);
                    }
                }, executor);
                completableFutures.add(completableFuture);
            }
            completableFutureUtil.getAllCompleted(completableFutures);
        }
        if (isMergeSignatureSuccess.get()) {
            signData.setStatus(MisaTransactionStatusEnum.MERGE_SUCCESS.getCode());
            signData.setSignTime(LocalDateTime.now());
        } else {
            signData.setStatus(MisaTransactionStatusEnum.MERGE_FAIL.getCode());
        }
        signDataRepository.save(signData);
        signDocumentRepository.saveAll(signDocumentEntities);
    }

    @DsTimer(uri = "/misa/merge/document")
    private @NotNull String merge(SignDataEntity signData, SignDocumentEntity signDoc, Map<Long, String> hashInfoBySignDocId, Map<String, String> signatureByDocId, ClientConfigDTO clientSignedPathFileConfig) throws Exception {
        String pdfHashInfoJson = hashInfoBySignDocId.get(signDoc.getId());
        String signature = signatureByDocId.get(signDoc.getDocId());
        //merge chữ ký
        ArrayList<byte[]> sigs = new ArrayList<>();
        sigs.add(Base64.getDecoder().decode(signature));
        PdfHashResult pdfHashResult = objectMapper.readValue(pdfHashInfoJson, PdfHashResult.class);
        PdfAttachSignatureData attachData = new PdfAttachSignatureData(pdfHashResult, sigs);
        List<byte[]> attachRes = new ArrayList<>(PDFSigner.attachSignature(attachData));
        String fileName = getFileNameFromPath(signDoc.getPathFile());
        String signedPathFile = clientSignedPathFileConfig.getValue().concat(fileName);
        boolean isUploadSuccess = minioService.uploadFile(dSignBucket, clientSignedPathFileConfig.getValue(), fileName, getFileTypeFromName(fileName), attachRes.get(0));
        if (!isUploadSuccess) {
            throw new Exception("[" + signData.getTransactionId() + "] upload signed file to minio fail [" + signedPathFile + "]");
        }
        return signedPathFile;
    }

    private String getFileNameFromPath(String path) {
        String[] paths = path.split("/");
        return paths[paths.length - 1];
    }

    private static String getFileTypeFromName(String fileName) {
        String[] names = fileName.split("\\.");
        return names[names.length - 1];
    }
}
