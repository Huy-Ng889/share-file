package vn.com.msb.infrastructure.config.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import vn.com.msb.infrastructure.comon.enums.ResponseStatus;

import java.io.IOException;

public class ResponseStatusSerializer extends JsonSerializer<ResponseStatus> {

    @Override
    public void serialize(ResponseStatus responseStatus, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeString(responseStatus.getCode());
    }
}
