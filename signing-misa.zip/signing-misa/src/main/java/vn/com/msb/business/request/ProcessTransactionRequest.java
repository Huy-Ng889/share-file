package vn.com.msb.business.request;

import lombok.Data;

@Data
public class ProcessTransactionRequest {
    private String transactionId;
    private String caProvider;
    private int status;
}
