package vn.com.msb.business.service.impl;

import vn.com.msb.business.service.ResponseMessageService;
import vn.com.msb.infrastructure.comon.enums.ResponseStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ResponseMessageServiceImpl implements ResponseMessageService {

    @Autowired
    @Qualifier("com.msb.esignature.infras.AppConfig.messageSource")
    private MessageSource messageSource;

    @Override
    public String getMessage(ResponseStatus responseStatus) {
        try {
            return messageSource.getMessage(responseStatus.getCode(), null, LocaleContextHolder.getLocale());
        } catch (Exception e) {
            log.error("ResponseMessageService - Exception when get message !!!", e);
            return null;
        }
    }
}
