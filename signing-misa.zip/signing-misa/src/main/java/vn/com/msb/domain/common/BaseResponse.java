package vn.com.msb.domain.common;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
@NoArgsConstructor
public class BaseResponse<T> {

//    @JsonSerialize(using = ResponseStatusSerializer.class)
    private String responseCode;

    private String responseDesc;

    private T data;

    public BaseResponse(T data) {
        this.data = data;
    }
}
