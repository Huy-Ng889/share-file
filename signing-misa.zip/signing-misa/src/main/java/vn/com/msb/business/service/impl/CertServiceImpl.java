package vn.com.msb.business.service.impl;

import org.springframework.cloud.sleuth.Tracer;
import vn.com.msb.business.service.CertService;
import vn.com.msb.domain.cert.InquiryCertDTO;
import vn.com.msb.domain.cert.entity.CertEntity;
import vn.com.msb.domain.cert.entity.CertRegisterEntity;
import vn.com.msb.domain.cert.model.Cert;
import vn.com.msb.domain.cert.model.CertificateInfo;
import vn.com.msb.domain.common.BaseResponse;
import vn.com.msb.infrastructure.client.CertificateDataClient;
import vn.com.msb.infrastructure.comon.utils.Util;
import vn.com.msb.infrastructure.repository.CertRegisterRepository;
import vn.com.msb.infrastructure.repository.CertRepository;
import vn.com.msb.infrastructure.comon.utils.Constant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class CertServiceImpl implements CertService {
    @Value("${misa.sign-signature.display-text}")
    private String displayText;

    private final CertRepository certRepository;
    private final CertRegisterRepository certRegisterRepository;
    private final CertificateDataClient certificateDataClient;
    private final Tracer tracer;

    @Override
    public CertificateInfo getCertificateInfo(String certId) {
        CertEntity certEntity = certRepository.findFirstByCertId(certId);
        String[] certChain = Objects.nonNull(certEntity.getCertChain()) ?
                certEntity.getCertChain().split(Constant.COMMA) : new String[0];
        CertificateInfo certInfo = new CertificateInfo();
        certInfo.setCertName(certEntity.getCertName());
        certInfo.setCertId(certEntity.getCertId());
        certInfo.setCertStatus(certEntity.getCertStatus());
        certInfo.setCertType(certEntity.getCertType());
        certInfo.setUserId(certEntity.getUserId());
        certInfo.setSerialNumber(certEntity.getSerialNumber());
        certInfo.setCertChain(new ArrayList<>(List.of(certChain)));
        certInfo.setCertRegisterId(certEntity.getCertRegisterId());
        return certInfo;
    }

    @Override
    public String buildDisplayCert(Cert certInfo) {
        String certName = certInfo.getCertName();
        CertRegisterEntity certRegisterEntity = certRegisterRepository.findById(certInfo.getCertRegisterId()).orElse(null);
        String title = "";
        String companyName = "";
        if (Objects.isNull(certRegisterEntity)) {
            log.info("not found certRegisterEntity of certId [{}]", certInfo.getCertId());
        } else {
            title = certRegisterEntity.getTitle();
            companyName = certRegisterEntity.getCompanyName();
        }
        return displayText.replace("_certName_", certName).replace("_title_", title).replace("_companyName_", companyName);
    }

    @Override
    public Cert getCertData(InquiryCertDTO inquiryCertDTO, String provider) {
        inquiryCertDTO.setCertStatus(0);
        Cert cert = null;
        try {
            BaseResponse<List<Cert>> response = certificateDataClient.inquiryCert(provider, inquiryCertDTO);
            cert = response.getData().get(0);
        } catch (Exception ex) {
            log.error("certificateDataClient.inquiryCert error {}", inquiryCertDTO, ex);
        }
        return cert;
    }
}
