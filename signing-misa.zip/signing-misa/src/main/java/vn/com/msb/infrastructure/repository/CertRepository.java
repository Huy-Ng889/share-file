package vn.com.msb.infrastructure.repository;

import vn.com.msb.domain.cert.entity.CertEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertRepository extends JpaRepository<CertEntity, Long> {
    CertEntity findFirstByCertId(String certId);
}
