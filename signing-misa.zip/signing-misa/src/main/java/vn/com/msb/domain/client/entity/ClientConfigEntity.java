package vn.com.msb.domain.client.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.common.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "client_configs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientConfigEntity extends BaseEntity {
    @Column(name = "client_id")
    private Long clientId;

    @Column(name = "name")
    private String name;

    @Column(name = "value")
    private String value;
}
