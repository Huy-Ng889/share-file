package vn.com.msb.infrastructure.metric;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.Duration;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class TimerUtils {
    private static final String DS_TIMER = "ds.timer";
    static final String URI = "uri";
    static final String STATUS = "status";
    static final String STATUS_200 = "200";
    static final String STATUS_500 = "500";

    public static Timer.Builder getBuilder() {
        return Timer.builder(DS_TIMER)
            .publishPercentiles(0, 0.5, 0.75, 0.90, 0.95, 0.99, 1.0)
            .sla(
                Duration.ofMillis(100), Duration.ofMillis(200), Duration.ofMillis(300),
                Duration.ofMillis(400), Duration.ofMillis(500), Duration.ofMillis(600),
                Duration.ofMillis(700), Duration.ofMillis(800), Duration.ofMillis(900),
                Duration.ofMillis(1000), Duration.ofMillis(1100), Duration.ofMillis(1200),
                Duration.ofMillis(1300), Duration.ofMillis(1400), Duration.ofMillis(1500),
                Duration.ofMillis(1600), Duration.ofMillis(1700), Duration.ofMillis(1800),
                Duration.ofMillis(1900), Duration.ofMillis(2000), Duration.ofMillis(2500),
                Duration.ofMillis(3000), Duration.ofMillis(4000), Duration.ofMillis(5000),
                Duration.ofMillis(6000), Duration.ofMillis(7000), Duration.ofMillis(8000),
                Duration.ofMillis(10000), Duration.ofMillis(15000), Duration.ofMillis(18000),
                Duration.ofMillis(20000), Duration.ofMillis(25000), Duration.ofMillis(30000),
                Duration.ofMillis(50000), Duration.ofMillis(60000), Duration.ofMillis(70000),
                Duration.ofMillis(100000), Duration.ofMillis(150000), Duration.ofMillis(180000),
                Duration.ofMillis(200000), Duration.ofMillis(250000), Duration.ofMillis(280000),
                Duration.ofMillis(300000), Duration.ofMillis(360000), Duration.ofMillis(420000),
                Duration.ofMillis(500000), Duration.ofMillis(550000), Duration.ofMillis(600000)
            )
            .minimumExpectedValue(Duration.ofMillis(1))
            .maximumExpectedValue(Duration.ofMillis(600000));
    }

    public static void timerDone(Timer.Builder builder, MeterRegistry registry, Timer.Sample sample, String status) {
        builder.tag(STATUS, status);
        Timer timer = builder.register(registry);
        sample.stop(timer);
    }

}
