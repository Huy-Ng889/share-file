package vn.com.msb.business.response.misa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MISABaseResponse {
    private int responseCode;
    private String responseMessage;
}
