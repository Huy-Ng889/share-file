package vn.com.msb.business.response;

import lombok.Data;
import vn.com.msb.domain.client.ClientConfigDTO;

import java.util.List;

@Data
public class ClientResponse {
    private String responseCode;
    private String responseDesc;
    private List<ClientConfigDTO> data;
}
