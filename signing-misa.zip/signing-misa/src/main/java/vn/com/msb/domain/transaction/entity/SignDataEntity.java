package vn.com.msb.domain.transaction.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.common.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "sign_datas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SignDataEntity extends BaseEntity {
    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "transaction_desc")
    private String transactionDesc;

    @Column(name = "ca_provider")
    private String caProvider;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "service_code")
    private String serviceCode;

    @Column(name = "cert_id")
    private String certId;

    @Column(name = "status")
    private int status;

    @Column(name = "sign_time")
    private LocalDateTime signTime;
}
