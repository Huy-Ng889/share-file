package vn.com.msb.infrastructure.config.logbook;

import lombok.Builder;
import org.zalando.logbook.HttpHeaders;
import org.zalando.logbook.HttpResponse;
import org.zalando.logbook.Origin;

import java.io.IOException;

@Builder
public class LogbookHttpResponse implements HttpResponse {
    @Builder.Default
    private int status = 0;
    @Builder.Default
    private Origin origin = Origin.REMOTE;
    @Builder.Default
    private HttpHeaders headers = HttpHeaders.empty();
    @Builder.Default
    private byte[] body = new byte[0];

    @Override
    public int getStatus() {
        return status;
    }

    @Override
    public HttpResponse withBody() throws IOException {
        return this;
    }

    @Override
    public HttpResponse withoutBody() {
        return this;
    }

    @Override
    public Origin getOrigin() {
        return origin;
    }

    @Override
    public HttpHeaders getHeaders() {
        return headers;
    }

    @Override
    public byte[] getBody() throws IOException {
        return body;
    }
}
