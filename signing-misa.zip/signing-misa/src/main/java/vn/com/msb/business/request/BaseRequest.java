package vn.com.msb.business.request;

import lombok.Data;

@Data
public class BaseRequest {
    private String transactionId;
}
