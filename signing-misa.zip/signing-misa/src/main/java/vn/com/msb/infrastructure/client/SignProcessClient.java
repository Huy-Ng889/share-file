package vn.com.msb.infrastructure.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import vn.com.msb.business.request.ProcessTransactionRequest;
import vn.com.msb.business.request.SignOrchestrationRequest;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.config.FeignConfig;

@FeignClient(name = "sign-process-client",
        url = "${signing-process-service-name}",
        configuration = FeignConfig.class)
public interface SignProcessClient {
    @PostMapping(value = "${d-signature.sign-process.change-process-transaction-state}")
    Object changeProcessTransactionState(@RequestBody ProcessTransactionRequest request);

    @PostMapping(value = "${d-signature.sign-process.publish-sign-orchestration}")
    Object publishEventToSignOrchestration(@RequestBody SignOrchestrationRequest request);
}
