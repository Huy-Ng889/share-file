package vn.com.msb.domain.cert.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Entity
@Table(name = "certs")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class CertEntity implements Serializable {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "user_id")
    private String userId;
    @Column(name = "cert_id", length = 50)
    private String certId;
    @Column(name = "ca_provider")
    private String caProvider;
    @Column(name = "cert_status")
    private Integer certStatus;
    @Column(name = "cert_type")
    private Integer certType;
    @Column(name = "cert_name")
    private String certName;
    @Column(name = "cert_chain")
    private String certChain;
    @Column(name = "serial_number", length = 100)
    private String serialNumber;
    @Column(name = "effective_time")
    private LocalDateTime effectiveTime;
    @Column(name = "expiration_time")
    private LocalDateTime expirationTime;
    @Column(name = "cert_register_id")
    private long certRegisterId;
}
