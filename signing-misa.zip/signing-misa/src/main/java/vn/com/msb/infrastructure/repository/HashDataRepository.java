package vn.com.msb.infrastructure.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.msb.domain.transaction.entity.HashDataEntity;

import java.util.List;

@Repository
public interface HashDataRepository extends JpaRepository<HashDataEntity, Long> {
    List<HashDataEntity> findBySignDocIdIn(List<Long> signDocIds);
}
