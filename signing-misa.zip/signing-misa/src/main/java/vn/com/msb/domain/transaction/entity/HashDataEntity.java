package vn.com.msb.domain.transaction.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Table(name = "hash_datas")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class HashDataEntity {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sign_doc_id")
    private Long signDocId;

    @Column(name = "hash_data")
    private String hashData;

    @Column(name = "hash_object")
    private String hashObject;
}
