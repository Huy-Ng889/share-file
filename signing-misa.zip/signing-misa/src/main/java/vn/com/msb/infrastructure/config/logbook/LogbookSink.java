package vn.com.msb.infrastructure.config.logbook;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.zalando.logbook.*;
import vn.com.msb.infrastructure.producer.KafkaProducer;

import java.io.IOException;

@Slf4j
@RequiredArgsConstructor
public class LogbookSink implements Sink {
    @Value("${spring.kafka.ds.topic.ds-log}")
    private String dsLogTopic;
    @Value("${spring.application.name}")
    private String serviceName;
    private final HttpLogFormatter formatter;
    private final KafkaProducer kafkaProducer;

    @Override
    public void write(@NonNull Precorrelation precorrelation, HttpRequest request) throws IOException {
        log("request", request.getRequestUri(), formatter.format(precorrelation, request), precorrelation.getId());
    }

    @Override
    public void write(@NonNull Correlation correlation, HttpRequest request, @NonNull HttpResponse response) throws IOException {
        log("response", request.getRequestUri(), formatter.format(correlation, response), correlation.getId());
    }

    private void log(String type, String uri, String logbookLog, String id) {
        if (!uri.contains("/actuator")) {
            log.info("{} | {} | {}", type, uri, logbookLog);
            kafkaProducer.send(dsLogTopic, id, new LogbookLog(serviceName, logbookLog, uri));
        }
    }

}
