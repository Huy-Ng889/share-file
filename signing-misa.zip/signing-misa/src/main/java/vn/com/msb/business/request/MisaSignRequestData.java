package vn.com.msb.business.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.msb.domain.transaction.model.MisaSignDocument;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MisaSignRequestData {
    private int authorizeMethod;
    private String certId;
    private List<MisaSignDocument> documents;
}
