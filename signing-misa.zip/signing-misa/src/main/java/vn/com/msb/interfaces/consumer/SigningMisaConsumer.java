package vn.com.msb.interfaces.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import vn.com.msb.business.service.MergeSignatureService;
import vn.com.msb.business.service.HashDocumentService;
import vn.com.msb.domain.transaction.entity.SignDataEntity;
import vn.com.msb.domain.transaction.model.MisaSignMessage;
import vn.com.msb.infrastructure.comon.enums.RecordSignTypeEnum;
import vn.com.msb.infrastructure.comon.utils.Constant;
import vn.com.msb.infrastructure.repository.SignDataRepository;

import java.util.Objects;

@Component
@Slf4j
@RequiredArgsConstructor
public class SigningMisaConsumer {
    private final HashDocumentService sendSignRequestToMISAHandler;
    private final MergeSignatureService misaSignResultHandler;
    private final SignDataRepository signDataRepository;
    private final ObjectMapper objectMapper;

    @KafkaListener(topics = "${spring.kafka.consumer.topic.sign-misa}",
            groupId = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void signingMisaConsumer(ConsumerRecord<String, String> record) {
        String key = record.key();
        String message = record.value();
        MisaSignMessage misaSignMessage = parseMessage(message);
        if (Objects.isNull(misaSignMessage)) {
            return;
        }
        if (RecordSignTypeEnum.HASH_FILE.getKey().equals(key)) {
            handleSignRequest(misaSignMessage);
        }
        if (RecordSignTypeEnum.MERGE_FILE.getKey().equals(key)) {
            misaSignResultHandler.handleMergeSignature(misaSignMessage.getTransactionId());
        }
        log.info("SigningMisaConsumer end with message [{}], key = [{}]", message, key);
    }

    void handleSignRequest(MisaSignMessage misaSignMessage) {
        try {
            log.info("SigningMisaConsumer start {}", misaSignMessage);
            SignDataEntity signDataEntity = signDataRepository.findByTransactionIdAndCaProvider(misaSignMessage.getTransactionId(), Constant.CA_PROVIDERS.MISA);
            if (Objects.isNull(signDataEntity)) {
                throw new Exception("Not found record for transactionId[" + misaSignMessage.getTransactionId() + "]");
            }
            if (!Objects.equals(signDataEntity.getStatus(), Constant.NOT_HANDLED)) {
                log.info("transactionId[{}] is handled", misaSignMessage.getTransactionId());
                return;
            }
            sendSignRequestToMISAHandler.handleSignRequest(signDataEntity, misaSignMessage.getAuthorizeMethod());
        } catch (Exception e) {
            log.error("SigningMisaConsumer hash error: {}", misaSignMessage, e);
        }
    }

    private MisaSignMessage parseMessage(String message) {
        try {
            return objectMapper.readValue(message, MisaSignMessage.class);
        } catch (Exception e) {
            log.error("parse message json error {}", message, e);
        }
        return null;
    }
}
